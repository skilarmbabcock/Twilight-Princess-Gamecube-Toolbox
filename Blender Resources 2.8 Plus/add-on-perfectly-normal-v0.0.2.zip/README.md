# Perfectly Normal
## Manipulate face-corner normals as mesh components.

This extension adds four simple geometry nodes-based tools under the "Normals" category in Blender. These tools let you work with *Manip Verts* (which are just loose/disconnected vertices) that are re-used to define custom face-corner normals for a mesh. Because they are just vertices, *you can precisely position them in edit mode like any other component*.

## Basic Workflow

1) Select a mesh and choose `Normals > Manip Verts: (Re)create` this will build the *Manip Verts* into the selected object.

2) In the modifiers tab `Add Modifier > Normals > Manip Verts: Apply` this will add the visualizing modifier and you should see normals as lines in the viewport at this point.

3) Enter edit mode and move the *Manip Verts* around, you will see the surface normals change in real time.

4) Once you are done, go back to the modifier, check "Ready to Apply" and apply the modifier, this will bake the custom normals into the mesh and clean up all *Manip Verts*.

## List of Tools

- `Object|Edit Mode` **"Normals" > "Manip Verts: (Re)create"** : Adds *Manip Verts* to a mesh, one for each face corner normal. Optionally, it can delete the original mesh and just return the isolated *Manip Verts* (used for a "multi-object workflow").

- `Object|Edit Mode` **"Normals" > "Manip Verts: Remove"** :  Deletes all *Manip Verts* from a mesh.

- `Edit Mode` **"Normals" > "Manip Verts: Tweak"**: A "Swiss Army Knife" tool. You can resize, converge, and clear modifications for selected *Manip Verts*. If nothing is selected, affects all *Manip Verts*. If any faces are selected, the corresponding *Manip Verts* for the face's corners will be affected. Optionally it will let you change your mesh selection to the affected *Manip Verts* or invert which are affected. 

-  `Modifier` **"Add Modifier" > "Normals" >"Manip Verts: Apply"**: *Using this modifier is required* in order to see any results. Adds a 
"visualizer" modifier to show normals as lines and also applies modified normals to a mesh. It has support for a "multi-object workflow" where you can pull the *Manip Verts* and/or mesh surface from *other objects* instead of getting this geometry directly from the stack mesh. Apply the modifier to commit the custom normals.

## "Pipeline" Workflow

This is ideal if you need to store custom normals separate from the mesh:

1. Duplicate a mesh object and (with the duplicate selected) choose **"Normals" > "Manip Verts: (Re)create"**, but check the option to keep "Only Manip Verts" this will leave you with two objects, the original mesh object and another that only has *Manip Verts* inside it

2. Options for adding the modifier:
	- **Option 1** *Pull the *Manip Verts* into the original mesh*: Back on the original mesh object, in the modifiers tab, `Add Modifier > Normals > Manip Verts: Apply`. Open the "Use External Geometry" panel and use the object picker for "Manip Verts" to select the duplicated mesh that only has *Manip Verts*.
	- **Option 2** *Pull the original mesh into the *Manip Verts**: Select the duplicated object only containing *Manip Verts* and add the modifier to it, then the "Use External Geometry" object picker for the "Mesh" can be used to select the original mesh object.
	- **Option 3** *Pull both into a third object* : Create some *third* mesh object and add the modifier to *that*. Now the "Use External Geometry" object pickers in the modifier can be used to select both the surface mesh from the original object, and the *Manip Verts* from the second object.
	
3. You should now be able to edit the *Manip Verts* object and see the custom normals being applied by the modifier, and can apply it when ready. 

------

## Caveats

The number of *Manip Verts* has to be the same as the number of face corners or the visualizing modifier will not work correctly. In a later version I will likely change this to store the mapping in a custom attribute so the one-to-one mapping is not required, although right now I'm on the fence about adding "surprise" attributes to user's meshes for things like this as they cannot be namespaced.

