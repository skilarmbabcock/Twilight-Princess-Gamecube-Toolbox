import bpy
import platform
from pathlib import Path
import os
import shutil

asset_libs = bpy.context.preferences.filepaths.asset_libraries
asset_name = "Perfectly Normal"
asset_from = "assets" #plugin dir folder containing assets to copy from

def get_home_dir():
    homedir = ".config/"
    sys = platform.system()
    if sys == "Windows":
        homedir = "AppData/Roaming/"
    elif sys == "Darwin":
        homedir = "Library/Application Support/"
    return Path.home().joinpath(homedir)

class Prefs(bpy.types.AddonPreferences):
    bl_idname = __name__
    
    user_location: bpy.props.StringProperty(
        name="Directory",
        description="Install location for assets",
        subtype='DIR_PATH',
        default=str(get_home_dir()) # seed to "ideal" home directory
    )

    live_location: bpy.props.StringProperty(
        name="Directory",
        description="Final location for assets",
        subtype='DIR_PATH',
        default=""
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="This addon manages its own asset library.")
        box = layout.box()
        if self.live_location:
            box.label(text="Asset library installed.", icon='CHECKMARK')
            box.label(text=self.live_location, icon='CHECKMARK')
        else:
            box.label(text="Asset library NOT installed!", icon='ERROR')
            box.prop(self, "user_location", text="Pick Install Directory")
            box.operator(PrefsInstall.bl_idname, icon='MODIFIER')
        box.operator(PrefsScan.bl_idname)

class PrefsInstall(bpy.types.Operator):
    bl_idname = "perfectly_normal.install"
    bl_label = "Install Assets"
    bl_description = "Adds assets to the user specified folder"

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        self.report({'INFO'}, f"Setting Install Dir To: {prefs.user_location}")

        src = os.path.join(os.path.dirname(os.path.realpath(__file__)), asset_from)
        dst = os.path.abspath(os.path.join(prefs.user_location, asset_name))
        
        try:
            os.makedirs(dst, exist_ok=True)
            for item in os.listdir(src):
                print(item, dst)
                s = os.path.join(src, item)
                shutil.copy(s, dst)
        except Exception as e:
            self.report({'ERROR'}, f"Failed: {str(e)}")
            return {'CANCELLED'}

        lib = asset_libs.new()
        lib.name = asset_name
        lib.path = dst
        lib.use_relative_path = False
        prefs.live_location = dst

        return {'FINISHED'}
    
class PrefsScan(bpy.types.Operator):
    bl_idname = "perfectly_normal.scan"
    bl_label = "Refresh"
    bl_description = "Check asset libraries for active installation"

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        check = asset_libs.get(asset_name)
        if check:
            prefs.live_location = check.path
            self.report({'INFO'}, f"Asset library found at: {check.path}")
        else:
            prefs.live_location = ""
            self.report({'WARNING'}, "Asset library not found")
        return {'FINISHED'}

classes = (
    Prefs,
    PrefsInstall,
    PrefsScan
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    lib = asset_libs.get(asset_name)
    if lib:
        asset_libs.remove(lib)

    for cls in classes:
        bpy.utils.unregister_class(cls)