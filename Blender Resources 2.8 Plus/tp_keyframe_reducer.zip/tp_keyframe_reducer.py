bl_info = {
    "name": "TP Smart Keyframe Reducer",
    "author": "Claude & tested by Ditrey (contador por Gemini)",
    "version": (1, 2, 0),
    "blender": (4, 0, 0),
    "location": "Graph Editor > N-Panel > TP Animation",
    "description": "An intelligent keyframe reduction tool for Twilight Princess modding with a keyframe counter.",
    "category": "Animation",
}

import bpy
import math
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import FloatProperty, IntProperty, BoolProperty, EnumProperty

def calculate_curve_error(fcurve, start_frame, end_frame, test_frame):
    """Calculates the error between linear interpolation and the actual value."""
    if start_frame == end_frame:
        return 0.0
    
    actual_value = fcurve.evaluate(test_frame)
    start_value = fcurve.evaluate(start_frame)
    end_value = fcurve.evaluate(end_frame)
    
    t = (test_frame - start_frame) / (end_frame - start_frame)
    interpolated_value = start_value + t * (end_value - start_value)
    
    return abs(actual_value - interpolated_value)

def is_significant_keyframe(fcurve, frame_index, keyframes, error_threshold, significant_flags):
    """Determines if a keyframe is significant based on interpolation error."""
    if frame_index == 0 or frame_index == len(keyframes) - 1:
        return True
    
    current_frame = keyframes[frame_index].co.x
    
    prev_significant = frame_index - 1
    while prev_significant > 0:
        if significant_flags[prev_significant]:
            break
        prev_significant -= 1
    
    next_significant = frame_index + 1
    while next_significant < len(keyframes) - 1:
        if significant_flags[next_significant]:
            break
        next_significant += 1
    
    prev_frame = keyframes[prev_significant].co.x
    next_frame = keyframes[next_significant].co.x
    
    error = calculate_curve_error(fcurve, prev_frame, next_frame, current_frame)
    
    return error > error_threshold

def analyze_motion_complexity(fcurve, start_frame, end_frame, samples=10):
    """Analyzes the complexity of motion within a frame range."""
    if start_frame >= end_frame:
        return 0.0
    
    total_variation = 0.0
    prev_value = fcurve.evaluate(start_frame)
    
    if (end_frame - start_frame) <= 0:
        return 0.0
        
    step = (end_frame - start_frame) / samples
    if step == 0:
        return 0.0

    for i in range(1, samples + 1):
        frame = start_frame + (end_frame - start_frame) * i / samples
        current_value = fcurve.evaluate(frame)
        total_variation += abs(current_value - prev_value)
        prev_value = current_value
    
    return total_variation / samples

class TP_SmartKeyframeReducer(Operator):
    """Smart keyframe reducer for Twilight Princess animations."""
    bl_idname = "anim.tp_smart_keyframe_reducer"
    bl_label = "Reduce Keyframes (TP Smart)"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return (context.area.type == 'GRAPH_EDITOR' and 
                context.selected_editable_fcurves) or (context.object and context.object.type == 'ARMATURE')
    
    def execute(self, context):
        scene = context.scene
        tp_props = scene.tp_keyframe_props
        
        fcurves_to_process = []
        
        if tp_props.selection_mode == 'GRAPH_SELECTED':
            if context.area.type == 'GRAPH_EDITOR':
                fcurves_to_process = context.selected_editable_fcurves
            else:
                self.report({'WARNING'}, "Switch to the Graph Editor to use 'Selected F-Curves Only'")
                return {'CANCELLED'}
                
        elif tp_props.selection_mode == 'POSE_SELECTED' and context.object and context.object.type == 'ARMATURE':
            armature = context.object
            if not armature.animation_data or not armature.animation_data.action:
                self.report({'WARNING'}, "No active animation action found")
                return {'CANCELLED'}
            
            action = armature.animation_data.action
            selected_bone_names = [bone.name for bone in armature.pose.bones if bone.bone.select]
            
            if not selected_bone_names:
                self.report({'WARNING'}, "No bones selected in Pose Mode")
                return {'CANCELLED'}
            
            for fcurve in action.fcurves:
                if fcurve.data_path.startswith('pose.bones["'):
                    bone_name = fcurve.data_path.split('["')[1].split('"]')[0]
                    if bone_name in selected_bone_names:
                        fcurves_to_process.append(fcurve)
                        
        elif tp_props.selection_mode == 'ALL_BONES' and context.object and context.object.type == 'ARMATURE':
            armature = context.object
            if not armature.animation_data or not armature.animation_data.action:
                self.report({'WARNING'}, "No active animation action found")
                return {'CANCELLED'}
            
            action = armature.animation_data.action
            fcurves_to_process = [fcurve for fcurve in action.fcurves 
                                if fcurve.data_path.startswith('pose.bones["')]
        
        if not fcurves_to_process:
            self.report({'WARNING'}, "No F-Curves to process")
            return {'CANCELLED'}
        
        bone_settings = {}
        if tp_props.use_bone_specific and context.object and context.object.type == 'ARMATURE':
            for bone_setting in tp_props.bone_settings:
                bone_settings[bone_setting.bone_name] = bone_setting
        
        total_removed = 0
        total_original = 0
        
        for fcurve in fcurves_to_process:
            if not fcurve.keyframe_points:
                continue
                
            original_count_fcurve = len(fcurve.keyframe_points)
            total_original += original_count_fcurve
            
            if original_count_fcurve <= 2:
                continue
            
            bone_name = None
            current_settings = tp_props
            
            if fcurve.data_path.startswith('pose.bones["') and tp_props.use_bone_specific:
                bone_name = fcurve.data_path.split('["')[1].split('"]')[0]
                if bone_name in bone_settings:
                    current_settings = bone_settings[bone_name]

            # --- PHASE 0: Stillness Detection ---
            if current_settings.use_stillness_detection and len(fcurve.keyframe_points) > current_settings.stillness_window_size:
                keyframes = fcurve.keyframe_points
                indices_to_remove_stillness = set()
                
                for i in range(len(keyframes) - current_settings.stillness_window_size + 1):
                    start_index = i
                    end_index = i + current_settings.stillness_window_size - 1
                    
                    start_frame = keyframes[start_index].co.x
                    end_frame = keyframes[end_index].co.x
                    
                    if start_frame >= end_frame:
                        continue
                    
                    complexity = analyze_motion_complexity(fcurve, start_frame, end_frame)
                    
                    if complexity < current_settings.stillness_threshold:
                        for j in range(start_index + 1, end_index):
                            indices_to_remove_stillness.add(j)
                
                if indices_to_remove_stillness:
                    for index in sorted(list(indices_to_remove_stillness), reverse=True):
                        keyframes.remove(keyframes[index])
                    fcurve.update()

            # --- MAIN REDUCTION PHASE ---
            
            if len(fcurve.keyframe_points) <= 2:
                final_count = len(fcurve.keyframe_points)
                removed = original_count_fcurve - final_count
                total_removed += removed
                continue

            if current_settings.ensure_first_frame:
                if len(fcurve.keyframe_points) > 0 and fcurve.keyframe_points[0].co.x != 1.0:
                    value_at_frame_1 = fcurve.evaluate(1.0)
                    fcurve.keyframe_points.insert(1.0, value_at_frame_1)
                    fcurve.update()
            
            keyframes = fcurve.keyframe_points
            
            significant_flags = [False] * len(keyframes)
            if len(significant_flags) > 0:
                significant_flags[0] = True
                significant_flags[-1] = True
            
            if current_settings.use_adaptive_analysis:
                section_size = max(10, len(keyframes) // current_settings.analysis_sections)
                for section_start in range(0, len(keyframes), section_size):
                    section_end = min(section_start + section_size, len(keyframes))
                    start_frame = keyframes[section_start].co.x
                    end_frame = keyframes[section_end - 1].co.x
                    complexity = analyze_motion_complexity(fcurve, start_frame, end_frame)
                    adaptive_threshold = current_settings.error_threshold * (1.0 + complexity * current_settings.complexity_factor)
                    for i in range(section_start, section_end):
                        if is_significant_keyframe(fcurve, i, keyframes, adaptive_threshold, significant_flags):
                            significant_flags[i] = True
            else:
                for i in range(len(keyframes)):
                    if is_significant_keyframe(fcurve, i, keyframes, current_settings.error_threshold, significant_flags):
                        significant_flags[i] = True
            
            if current_settings.min_frame_distance > 1 and len(keyframes) > 2:
                selected_indices = [i for i, flag in enumerate(significant_flags) if flag]
                if selected_indices:
                    filtered_selection = [selected_indices[0]]
                    for i in range(1, len(selected_indices) - 1):
                        current_idx = selected_indices[i]
                        prev_idx = filtered_selection[-1]
                        frame_distance = keyframes[current_idx].co.x - keyframes[prev_idx].co.x
                        if frame_distance >= current_settings.min_frame_distance:
                            filtered_selection.append(current_idx)
                    filtered_selection.append(selected_indices[-1])
                    significant_flags = [i in filtered_selection for i in range(len(keyframes))]
            
            keyframes_to_remove = [i for i, flag in enumerate(significant_flags) if not flag]
            
            for i in reversed(keyframes_to_remove):
                keyframes.remove(keyframes[i])
            
            fcurve.update()
            
            final_count = len(fcurve.keyframe_points)
            removed = original_count_fcurve - final_count
            total_removed += removed
            
            if current_settings.post_smooth and final_count > 2:
                for keyframe in fcurve.keyframe_points:
                    if current_settings.smooth_type == 'BEZIER':
                        keyframe.interpolation = 'BEZIER'
                        keyframe.handle_left_type = 'AUTO'
                        keyframe.handle_right_type = 'AUTO'
                    elif current_settings.smooth_type == 'LINEAR':
                        keyframe.interpolation = 'LINEAR'
        
        self.report({'INFO'}, f"Removed {total_removed} of {total_original} total keyframes")
        return {'FINISHED'}

class TP_AnalyzeCurves(Operator):
    """Analyzes the selected f-curves to show statistics"""
    bl_idname = "anim.tp_analyze_curves"
    bl_label = "Analyze Curves"
    bl_options = {'REGISTER'}
    
    @classmethod
    def poll(cls, context):
        return (context.area.type == 'GRAPH_EDITOR' and 
                context.selected_editable_fcurves)
    
    def execute(self, context):
        fcurves = context.selected_editable_fcurves
        total_keyframes = 0
        complexity_scores = []
        for fcurve in fcurves:
            if not fcurve.keyframe_points: continue
            keyframe_count = len(fcurve.keyframe_points)
            total_keyframes += keyframe_count
            if keyframe_count > 1:
                start_frame = fcurve.keyframe_points[0].co.x
                end_frame = fcurve.keyframe_points[-1].co.x
                complexity = analyze_motion_complexity(fcurve, start_frame, end_frame)
                complexity_scores.append(complexity)
        avg_complexity = sum(complexity_scores) / len(complexity_scores) if complexity_scores else 0
        message = f"Total Keyframes: {total_keyframes}\n"
        message += f"Average Complexity: {avg_complexity:.3f}\n"
        message += f"F-Curves Analyzed: {len(fcurves)}"
        self.report({'INFO'}, message)
        return {'FINISHED'}

class TP_EnsureFirstFrameKeys(Operator):
    """Ensures all bones have a keyframe on frame 1"""
    bl_idname = "anim.tp_ensure_first_frame"
    bl_label = "Ensure Frame 1"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'ARMATURE'
    
    def execute(self, context):
        armature = context.object
        if not armature.animation_data or not armature.animation_data.action:
            self.report({'WARNING'}, "No active animation action found")
            return {'CANCELLED'}
        action = armature.animation_data.action
        original_frame = context.scene.frame_current
        context.scene.frame_set(1)
        bpy.context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='POSE')
        for bone in armature.pose.bones:
            bone.bone.select = True
        bpy.ops.anim.keyframe_insert_menu(type='Rotation')
        bpy.ops.anim.keyframe_insert_menu(type='Location')
        context.scene.frame_set(original_frame)
        self.report({'INFO'}, "Ensured keyframes on frame 1 for all bones")
        return {'FINISHED'}

class TP_AddBoneSetting(Operator):
    """Add a specific setting override for a bone"""
    bl_idname = "anim.tp_add_bone_setting"
    bl_label = "Add Bone"
    bl_options = {'REGISTER', 'UNDO'}
    
    bone_name: bpy.props.StringProperty(name="Bone Name")
    
    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'ARMATURE'
    
    def invoke(self, context, event):
        if context.active_pose_bone:
            self.bone_name = context.active_pose_bone.name
        return context.window_manager.invoke_props_dialog(self)
    
    def execute(self, context):
        scene = context.scene
        tp_props = scene.tp_keyframe_props
        if not self.bone_name:
            self.report({'WARNING'}, "You must specify a bone name")
            return {'CANCELLED'}
        for bone_setting in tp_props.bone_settings:
            if bone_setting.bone_name == self.bone_name:
                self.report({'WARNING'}, f"Settings for bone '{self.bone_name}' already exist")
                return {'CANCELLED'}
        new_setting = tp_props.bone_settings.add()
        new_setting.bone_name = self.bone_name
        
        # Copy global settings as a baseline
        new_setting.error_threshold = tp_props.error_threshold
        new_setting.min_frame_distance = tp_props.min_frame_distance
        new_setting.use_adaptive_analysis = tp_props.use_adaptive_analysis
        new_setting.analysis_sections = tp_props.analysis_sections
        new_setting.complexity_factor = tp_props.complexity_factor
        new_setting.ensure_first_frame = tp_props.ensure_first_frame
        new_setting.post_smooth = tp_props.post_smooth
        new_setting.smooth_type = tp_props.smooth_type
        new_setting.use_stillness_detection = tp_props.use_stillness_detection
        new_setting.stillness_threshold = tp_props.stillness_threshold
        new_setting.stillness_window_size = tp_props.stillness_window_size
        
        tp_props.bone_settings_index = len(tp_props.bone_settings) - 1
        self.report({'INFO'}, f"Added settings for bone '{self.bone_name}'")
        return {'FINISHED'}

class TP_RemoveBoneSetting(Operator):
    """Remove a bone's specific setting override"""
    bl_idname = "anim.tp_remove_bone_setting"
    bl_label = "Remove Bone"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return len(context.scene.tp_keyframe_props.bone_settings) > 0
    
    def execute(self, context):
        tp_props = context.scene.tp_keyframe_props
        if tp_props.bone_settings_index < len(tp_props.bone_settings):
            bone_name = tp_props.bone_settings[tp_props.bone_settings_index].bone_name
            tp_props.bone_settings.remove(tp_props.bone_settings_index)
            if tp_props.bone_settings_index >= len(tp_props.bone_settings):
                tp_props.bone_settings_index = max(0, len(tp_props.bone_settings) - 1)
            self.report({'INFO'}, f"Removed settings for bone '{bone_name}'")
        return {'FINISHED'}

class TP_BoneSettings(PropertyGroup):
    """Bone-specific settings"""
    bone_name: bpy.props.StringProperty(name="Bone Name")
    error_threshold: FloatProperty(name="Error Threshold", description="Specific error threshold for this bone", default=0.001, min=0.0001, max=1.0, precision=4)
    min_frame_distance: IntProperty(name="Min Distance", description="Specific minimum frame distance for this bone", default=2, min=1, max=10)
    use_adaptive_analysis: BoolProperty(name="Adaptive Analysis", description="Specific adaptive analysis for this bone", default=True)
    analysis_sections: IntProperty(name="Analysis Sections", description="Specific analysis sections for this bone", default=8, min=4, max=20)
    complexity_factor: FloatProperty(name="Complexity Factor", description="Specific complexity factor for this bone", default=0.5, min=0.1, max=2.0)
    
    use_stillness_detection: BoolProperty(name="Stillness Detection", description="Remove keyframes in low-motion areas for this bone", default=False)
    stillness_threshold: FloatProperty(name="Stillness Threshold", description="Motion threshold below which it is considered 'still'", default=0.0005, min=0.0, max=0.1, precision=5)
    stillness_window_size: IntProperty(name="Stillness Window", description="Number of keyframes to analyze for stillness", default=10, min=3, max=50)

    ensure_first_frame: BoolProperty(name="Ensure Frame 1", description="Specific ensure frame 1 for this bone", default=True)
    post_smooth: BoolProperty(name="Post-process Smooth", description="Specific post-smoothing for this bone", default=True)
    smooth_type: EnumProperty(name="Smooth Type", items=[('BEZIER', "Bezier", ""), ('LINEAR', "Linear", "")], default='BEZIER')

class TP_KeyframeProperties(PropertyGroup):
    """Properties for the keyframe reducer"""
    selection_mode: EnumProperty(
        name="Selection Mode",
        description="Which elements to process",
        items=[
            ('GRAPH_SELECTED', "Selected F-Curves Only", "Process only the selected F-Curves in the Graph Editor"),
            ('POSE_SELECTED', "Selected Bones Only", "Process only the selected bones in Pose Mode"),
            ('ALL_BONES', "All Bones", "Process all bones in the armature")
        ],
        default='GRAPH_SELECTED'
    )
    use_bone_specific: BoolProperty(name="Use Per-Bone Settings", description="Use specific settings for individual bones", default=False)
    bone_settings: bpy.props.CollectionProperty(type=TP_BoneSettings)
    bone_settings_index: IntProperty(default=0)
    
    error_threshold: FloatProperty(name="Error Threshold", description="Error margin to consider a keyframe significant", default=0.001, min=0.0001, max=1.0, precision=4)
    min_frame_distance: IntProperty(name="Min Distance", description="Minimum frame distance between keyframes", default=2, min=1, max=10)
    
    use_adaptive_analysis: BoolProperty(name="Adaptive Analysis", description="Adjust the threshold based on the complexity of each section", default=True)
    analysis_sections: IntProperty(name="Analysis Sections", description="Number of sections for adaptive analysis", default=8, min=4, max=20)
    complexity_factor: FloatProperty(name="Complexity Factor", description="Multiplier to adjust threshold based on complexity", default=0.5, min=0.1, max=2.0)

    use_stillness_detection: BoolProperty(
        name="Stillness Detection",
        description="Enable to remove keyframes in very low-motion areas before the main analysis",
        default=False
    )
    stillness_threshold: FloatProperty(
        name="Stillness Threshold",
        description="Curve sections with variation below this threshold are considered 'still'",
        default=0.0005, min=0.0, max=0.1, precision=5
    )
    stillness_window_size: IntProperty(
        name="Analysis Window (keyframes)",
        description="The number of consecutive keyframes to analyze for stillness",
        default=10, min=3, max=50
    )
    
    ensure_first_frame: BoolProperty(name="Ensure Frame 1", description="Guarantee a keyframe on frame 1 (required for TP)", default=True)
    post_smooth: BoolProperty(name="Post-process Smooth", description="Apply smoothing after reduction", default=True)
    smooth_type: EnumProperty(name="Smooth Type", items=[('BEZIER', "Bezier", ""), ('LINEAR', "Linear", "")], default='BEZIER')

class TP_AnimationPanel(Panel):
    """Main addon panel"""
    bl_label = "TP Animation Tools"
    bl_idname = "GRAPH_PT_tp_animation"
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = "TP Animation"
    
    def draw(self, context):
        layout = self.layout
        tp_props = context.scene.tp_keyframe_props
        
        # --- NUEVA SECCIÓN: CONTADOR DE KEYFRAMES ---
        info_box = layout.box()
        info_box.label(text="Selection Info:", icon='INFO')

        total_keyframes = 0
        selected_bone_count = 0
        
        obj = context.object
        if obj and obj.type == 'ARMATURE' and obj.animation_data and obj.animation_data.action:
            if obj.mode == 'POSE':
                selected_bones = {bone.name for bone in obj.pose.bones if bone.bone.select}
                selected_bone_count = len(selected_bones)
                
                if selected_bone_count > 0:
                    action = obj.animation_data.action
                    for fcurve in action.fcurves:
                        if fcurve.data_path.startswith('pose.bones["'):
                            # Extrae el nombre del hueso de forma segura
                            try:
                                bone_name = fcurve.data_path.split('"')[1]
                                if bone_name in selected_bones:
                                    total_keyframes += len(fcurve.keyframe_points)
                            except IndexError:
                                continue # Ignora data_paths mal formados
                    
                    info_box.label(text=f"Selected Bones: {selected_bone_count}")
                    info_box.label(text=f"Total Keyframes: {total_keyframes}")
                else:
                    info_box.label(text="No bones selected in Pose Mode", icon='RESTRICT_SELECT_OFF')
            else:
                info_box.label(text="Switch to Pose Mode to see stats", icon='POSE_HLT')
        else:
            info_box.label(text="Select an Armature with an Action", icon='ARMATURE_DATA')

        # --- FIN DE LA NUEVA SECCIÓN ---

        box = layout.box()
        box.label(text="Target Selection:", icon='RESTRICT_SELECT_OFF')
        box.prop(tp_props, "selection_mode", text="")
        
        if tp_props.selection_mode == 'POSE_SELECTED':
            if context.object and context.object.type == 'ARMATURE':
                selected_bones = [bone.name for bone in context.object.pose.bones if bone.bone.select]
                if not selected_bones:
                    # Este mensaje ahora es redundante por el panel de arriba, pero se mantiene por consistencia
                    box.label(text="No bones selected", icon='ERROR')
            else:
                box.label(text="Active object must be an armature", icon='ERROR')

        box = layout.box()
        box.label(text="Analysis:", icon='VIEWZOOM')
        box.operator("anim.tp_analyze_curves")
        
        box = layout.box()
        box.label(text="Per-Bone Settings:", icon='BONE_DATA')
        box.prop(tp_props, "use_bone_specific")
        
        if tp_props.use_bone_specific:
            row = box.row()
            row.template_list("UI_UL_list", "", tp_props, "bone_settings", 
                            tp_props, "bone_settings_index", rows=3)
            col = row.column(align=True)
            col.operator("anim.tp_add_bone_setting", icon='ADD', text="")
            col.operator("anim.tp_remove_bone_setting", icon='REMOVE', text="")
            
            if tp_props.bone_settings and tp_props.bone_settings_index < len(tp_props.bone_settings):
                bone_setting = tp_props.bone_settings[tp_props.bone_settings_index]
                sub_box = box.box()
                sub_box.label(text=f"Settings: {bone_setting.bone_name}", icon='BONE_DATA')
                
                col = sub_box.column(align=True)
                col.prop(bone_setting, "use_stillness_detection")
                if bone_setting.use_stillness_detection:
                    sub_col = col.column(align=True)
                    sub_col.prop(bone_setting, "stillness_threshold")
                    sub_col.prop(bone_setting, "stillness_window_size")
                col.separator()
                
                col.prop(bone_setting, "error_threshold")
                col.prop(bone_setting, "min_frame_distance")
                col.prop(bone_setting, "use_adaptive_analysis")
                if bone_setting.use_adaptive_analysis:
                    sub = col.column(align=True)
                    sub.prop(bone_setting, "analysis_sections")
                    sub.prop(bone_setting, "complexity_factor")
                col.separator()
                col.prop(bone_setting, "ensure_first_frame")
                col.prop(bone_setting, "post_smooth")
                if bone_setting.post_smooth:
                    col.prop(bone_setting, "smooth_type")
        
        if not tp_props.use_bone_specific:
            box = layout.box()
            box.label(text="Phase 1: Stillness Detection", icon='REMOVE')
            box.prop(tp_props, "use_stillness_detection")
            if tp_props.use_stillness_detection:
                sub = box.column(align=True)
                sub.prop(tp_props, "stillness_threshold")
                sub.prop(tp_props, "stillness_window_size")

            box = layout.box()
            box.label(text="Phase 2: Smart Reduction", icon='SETTINGS')
            box.prop(tp_props, "error_threshold")
            box.prop(tp_props, "min_frame_distance")
            
            box.prop(tp_props, "use_adaptive_analysis")
            if tp_props.use_adaptive_analysis:
                sub = box.column(align=True)
                sub.prop(tp_props, "analysis_sections")
                sub.prop(tp_props, "complexity_factor")
            
            box = layout.box()
            box.label(text="Final Options:", icon='MODIFIER')
            box.prop(tp_props, "ensure_first_frame")
            box.prop(tp_props, "post_smooth")
            if tp_props.post_smooth:
                box.prop(tp_props, "smooth_type")
        
        layout.separator()
        col = layout.column(align=True)
        col.scale_y = 1.2
        col.operator("anim.tp_smart_keyframe_reducer", icon='GRAPH')
        col.operator("anim.tp_ensure_first_frame", icon='KEYFRAME_HLT')

classes = [
    TP_BoneSettings, TP_KeyframeProperties, TP_SmartKeyframeReducer,
    TP_AnalyzeCurves, TP_EnsureFirstFrameKeys, TP_AddBoneSetting,
    TP_RemoveBoneSetting, TP_AnimationPanel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.tp_keyframe_props = bpy.props.PointerProperty(type=TP_KeyframeProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.tp_keyframe_props

if __name__ == "__main__":
    register()